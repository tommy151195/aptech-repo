﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FakeNews.Models
{
    public class NewsItem
    {
        public int Id { get; set; }
        public string Category { get; set; }
        public string Headline { get; set; }
        public string Subhead { get; set; }
        public string DateLine { get; set; }
        public string Image { get; set; }
    }

    public class NewsManager
    {

        public static void GetNews(string category, ObservableCollection<NewsItem> newsItems)
        {
            var allItems = getNewsItems();
            var filteredNewsItems = allItems.Where(p => p.Category == category).ToList();
            newsItems.Clear();
            filteredNewsItems.ForEach(p => newsItems.Add(p));
        }

        private static List<NewsItem> getNewsItems()
        {
            var items = new List<NewsItem>();
            items.Add(new NewsItem()
            {
                Id = 1,
                Category = "Financial",
                Headline = "Lorem Ipsum",
                Subhead = "Let him pursue"
                    ,
                DateLine = "Duis sit amet",
                Image = "Assets/Financial.png"
            });

            items.Add(new NewsItem()
            {
                Id = 2,
                Category = "Financial",
                Headline = "Lorem Ipsum 2",
                Subhead =  "In adipiscing ultrices"
                    ,
                DateLine = "Duis nunc eros",
                Image = "Assets/Financial3.png"
            });

            items.Add(new NewsItem()
            {
                Id = 3,
                Category = "Financial",
                Headline = "Lorem Ipsum 3",
                Subhead = "Nulla aliquet"
                    ,
                DateLine = "Nam hendrerit",
                Image = "Assets/Financial4.png"
            });

            items.Add(new NewsItem()
            {
                Id = 4,
                Category = "Financial",
                Headline = "Lorem Ipsum 4",
                Subhead = "Sed ut perspiciatis"
                    ,
                DateLine = "Excepteur sint occaecat",
                Image = "Assets/Financial5.png"
            });

            items.Add(new NewsItem()
            {
                Id = 5,
                Category = "Food",
                Headline = "Lorem Ipsum 5",
                Subhead = "Ut enim ad"
                    ,
                DateLine = "Duis aute irure dolor",
                Image = "Assets/Food.png"
            });

            items.Add(new NewsItem()
            {
                Id = 6,
                Category = "Food",
                Headline = "Lorem Ipsum 6",
                Subhead = "Commodi consequatur"
                    ,
                DateLine = "Quis autem vel",
                Image = "Assets/Food1.png"
            });

            items.Add(new NewsItem()
            {
                Id = 7,
                Category = "Food",
                Headline = "Lorem Ipsum 7",
                Subhead = "Reprehenderit qui in"
                    ,
                DateLine = "Velit esse quam nihil ",
                Image = "Assets/Food2.png"
            });

            items.Add(new NewsItem()
            {
                Id = 8,
                Category = "Food",
                Headline = "Lorem Ipsum 8",
                Subhead = "Nemo enim ipsam"
                    ,
                DateLine = "Numquam eius modir",
                Image = "Assets/Food3.png"
            });

            items.Add(new NewsItem()
            {
                Id = 9,
                Category = "Food",
                Headline = "Lorem Ipsum 9",
                Subhead = "Vsoluptatem accusantium"
                    ,
                DateLine = "Molestiae consequatur",
                Image = "Assets/Food4.png"
            });

            items.Add(new NewsItem()
            {
                Id = 10,
                Category = "Food",
                Headline = "Lorem Ipsum 10",
                Subhead = "Necessitatibus saepe"
                    ,
                DateLine = "Voluptatibus maiores alias",
                Image = "Assets/Food5.png"
            });

            return items;
        }
    }
}
