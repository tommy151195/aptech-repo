﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xBindDataExample.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string CoverImage { get; set; }

    }

    public class BookManager
    {
        public static List<Book> GetBooks()
        {
            var books = new List<Book>();
            books.Add(new Book { BookId = 1, Title = "Lapabo", Author = "Tommy Hoang", CoverImage = "Assets/1.png" });
            books.Add(new Book { BookId = 2, Title = "Loco Techies", Author = "Jane", CoverImage = "Assets/2.png" });
            books.Add(new Book { BookId = 3, Title = "No Future", Author = "Lonely Pop", CoverImage = "Assets/3.png" });
            books.Add(new Book { BookId = 4, Title = "Hope is blue", Author = "Adam Khoo", CoverImage = "Assets/4.png" });
            books.Add(new Book { BookId = 5, Title = "I am legend", Author = "Tony Robbins", CoverImage = "Assets/5.png" });
            books.Add(new Book { BookId = 6, Title = "Pika Pika Pikachu", Author = "Ernest Wong", CoverImage = "Assets/6.png" });
            books.Add(new Book { BookId = 7, Title = "Love is blue", Author = "Kyle Landry", CoverImage = "Assets/7.png" });
            books.Add(new Book { BookId = 8, Title = "Walking dead", Author = "Chopin", CoverImage = "Assets/8.png" });
            books.Add(new Book { BookId = 9, Title = "Love story", Author = "April Nguyen", CoverImage = "Assets/9.png" });
            books.Add(new Book { BookId = 10, Title = "Can't feel my face", Author = "Austin Tran", CoverImage = "Assets/10.png" });
            books.Add(new Book { BookId = 11, Title = "True story", Author = "John Legend", CoverImage = "Assets/11.png" });
            books.Add(new Book { BookId = 12, Title = "The sad bamboo", Author = "Cool deep shit", CoverImage = "Assets/12.png" });
            books.Add(new Book { BookId = 13, Title = "Juke in jungle", Author = "Orange Juice", CoverImage = "Assets/13.png" });
            return books;
        }
    }
}
